import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-testinput',
  templateUrl: './testinput.component.html',
  styleUrls: ['./testinput.component.scss']
})
export class TestinputComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
